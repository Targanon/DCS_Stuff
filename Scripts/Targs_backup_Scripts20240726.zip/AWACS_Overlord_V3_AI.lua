----------------------------------------------------------------------
--SPA-124 - Air Ops - Scheduled Spawns with OnSpawnGroup() Escort Task
----------------------------------------------------------------------
 --//////////////////////////////////
 --////////////AWACSs and awacs v1
 --//////////////////////////////////
--////////// By Targs35 /////////////
--//////////////// from 62nd Air Wing, Brisbane server..
--///////////////////////////////////
 ------- With thanks to the guys at MOOSE and in particular Pikes, Nolove, Delta99 and Wingthor
 -- Funky Frank is the man..
-----////////////////////////////////
--///////////  Spawn AWACS and Escorts  ///

--This version of the AWACS overlord script has been enhanced by ChatGPT.


-- Create a function to spawn an escort group and define its follow task
function spawnEscortWithTask(escortName, awacsGroup, taskOffset)
    local escortSpawn = SPAWN
      :New(escortName)
      :InitLimit(1, 2)
      :InitCleanUp(240)
      :OnSpawnGroup(function(spawnedGroup)
        local followTask = spawnedGroup:TaskFollow(awacsGroup, taskOffset)
        spawnedGroup:SetTask(followTask, 1)
      end)
      :SpawnScheduled(60, 0.5)
    return escortSpawn
  end
  
  -- Define the position offsets for the escorts
  local escortOffset1 = POINT_VEC3:New(-100, 10, -100)
  local escortOffset2 = POINT_VEC3:New(-100, 10, 100)
  
  -- Create a function to spawn an AWACS group and its escorts
  function spawnAwacsWithEscorts()
    local awacsSpawn = SPAWN
      :New("AWACS_Overlord_E_3A")
      :InitLimit(1, 2)
      :InitCleanUp(240)
      :OnSpawnGroup(function(awacsGroup)
        -- Spawn two escort groups and define their follow tasks
        local escortSpawn1 = spawnEscortWithTask("Escort_Overlord_F15 001", awacsGroup, escortOffset1)
        local escortSpawn2 = spawnEscortWithTask("Escort_Overlord_F15 002", awacsGroup, escortOffset2)
      end)
      :SpawnScheduled(60, 0.5)
    return awacsSpawn
  end
  
  -- Spawn the AWACS group with escorts
  spawnAwacsWithEscorts()