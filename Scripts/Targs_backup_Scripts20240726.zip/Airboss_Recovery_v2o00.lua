-------------------------
-- AIRBOSS Targs Script SB3 Tanker --
-------------------------

-- Debug flag to enable/disable detailed logging
local DEBUG = true

-- Custom logging functions
local function logInfo(message)
  if DEBUG then
    env.info(message)
  end
end

local function logError(message)
  env.error(message)
  local logFile = io.open(lfs.writedir() .. "Logs/airboss_error.log", "a")
  logFile:write(message .. "\n")
  logFile:close()
end

-- Function to safely execute code and log errors
local function safeExecute(func, ...)
  local status, err = pcall(func, ...)
  if not status then
    logError(err)
  end
end

---Naming of objects in ME.
-- Carrier
----------  GroupName   ="CVN 72 Abraham Lincoln"
----------  UnitName    ="CVN 72 Abraham Lincoln"
-- Tanker  
----------  GroupName   ="S_3B Arco"
----------  UnitName    ="S_3B Arco"
-- AWACS  
----------  GroupName   ="E2D Wizard"
----------  UnitName    ="E2D Wizard"
-- rescuehelo_1
----------  GroupName   ="SQ BLUE CH_53E"
----------  UnitName    ="SQ BLUE CH_53E"
-- rescuehelo_2
----------  GroupName   ="SQ BLUE SH_60B"
----------  UnitName    ="SQ BLUE SH_60B"
-- rescuehelo_3
----------  GroupName   ="SQ BLUE SH_60BSC"
----------  UnitName    ="SQ BLUE SH_60BSC"
-- DD for rescuehelo_1 
----------  GroupName   ="CVN 72 Abraham Lincoln"
----------  UnitName    ="USS Perry"
-- DD for rescuehelo_2 
----------  GroupName   ="CVN 72 Abraham Lincoln"
----------  UnitName    ="LHA_1 Tarawa"
-- DD for rescuehelo_3 
----------  GroupName   ="CVN 70 Vinson"
----------  UnitName    ="CVN 70 Vinson"

-- No MOOSE settings menu. Comment out this line if required.
BASE:TraceOnOff(false)

_SETTINGS:SetPlayerMenuOff()

-- S-3B Recovery Tanker spawning in air.
safeExecute(function()
  local tanker = RECOVERYTANKER:New("CVN 72 Abraham Lincoln", "S_3B Arco")
  -- Custom Settings
  tanker:SetTakeoffAir()
  tanker:SetRadio(262)
  tanker:SetModex(262)
  tanker:SetSpeed(350)
  tanker:SetTACAN(62, "ARC")
  tanker:__Start(1)
end)

-- E-2D AWACS spawning on Lincoln.
safeExecute(function()
  local awacs = RECOVERYTANKER:New("CVN 72 Abraham Lincoln", "E2D Wizard")
  -- Custom Settings
  awacs:SetAWACS()
  awacs:SetTakeoffAir()
  awacs:SetRadio(251)
  awacs:SetAltitude(25000)
  awacs:SetCallsign(CALLSIGN.AWACS.Wizard)
  awacs:SetRacetrackDistances(30, 50)
  awacs:SetModex(251)
  awacs:SetTACAN(51, "WIZ")
  awacs:__Start(1)
end)

-- Rescue Helo with home base USS Perry. Has to be a global object!
safeExecute(function()
  local rescuehelo_1 = RESCUEHELO:New("CVN 72 Abraham Lincoln", "SQ BLUE CH_53E")
  rescuehelo_1:SetHomeBase(AIRBASE:FindByName("USS Perry"))
  rescuehelo_1:SetRescueZone(10)
  rescuehelo_1:SetTakeoffCold()
  rescuehelo_1:SetModex(42)
  rescuehelo_1:__Start(1)
end)

-- Create AIRBOSS object. Lincoln
safeExecute(function()
  local AirbossLincoln = AIRBOSS:New("CVN 72 Abraham Lincoln", "CVN 72 Abraham Lincoln")
  AirbossLincoln:SetCollisionDistance(10)
  --AirbossLincoln:SetCarrierControlledArea(60)
  --AirbossLincoln:SetCarrierControlledZone(10)
  
  -- Set the TACAN frequency
  AirbossLincoln:SetTACAN(72, "X", "ABL")
  
  -- Set ICLS channel of carrier.
  AirbossLincoln:SetICLS(12, "ABL")
  
  -- Set radio for LSO
  AirbossLincoln:SetLSORadio(127400, "AM")
  
  -- Set radio for Marshall
  AirbossLincoln:SetMarshalRadio(127400, "AM")
  
  AirbossLincoln:SetWelcomePlayers(false)
  
  -- Add recovery windows:
  AirbossLincoln:SetMenuRecovery(30, 25, true, nil)
  -- Case I from 9 to 10 am.
  -- AirbossLincoln:AddRecoveryWindow("8:10", "9:30", 1, nil, true, 25, false)
  -- AirbossLincoln:AddRecoveryWindow("11:00", "12:30", 1, nil, true, 25, true)
  -- AirbossLincoln:AddRecoveryWindow("14:00", "15:30", 1, nil, true, 25, false)
  
  -- Set folder of airboss sound files within miz file.
  AirbossLincoln:SetSoundfilesFolder("Airboss Soundfiles/")
  
  -- Single carrier menu optimization.
  AirbossLincoln:SetMenuSingleCarrier(false)
  
  -- Skipper menu.
  AirbossLincoln:SetMenuRecovery(30, 20, false)
  
  -- Remove landed AI planes from flight deck.
  AirbossLincoln:SetDespawnOnEngineShutdown()
  
  -- Load all saved player grades from your "Saved Games\DCS" folder (if lfs was desanitized).
  AirbossLincoln:Load()
  
  -- Automatically save player results to your "Saved Games\DCS" folder each time a player gets a final grade from the LSO.
  AirbossLincoln:SetAutoSave()
  
  -- Enable trap sheet.
  AirbossLincoln:SetTrapSheet()
  
  -- Start airboss class.
  AirbossLincoln:Start()
  
  -- Function called when recovery tanker is started.
  function tanker:OnAfterStart(From, Event, To)
    -- Set recovery tanker.
    AirbossLincoln:SetRecoveryTanker(tanker)
  
    -- Use tanker as radio relay unit for LSO transmissions.
    AirbossLincoln:SetRadioRelayLSO(self:GetUnitName())
  end
  
  -- Function called when AWACS is started.
  function awacs:OnAfterStart(From, Event, To)
    -- Set AWACS.
    AirbossLincoln:SetRecoveryTanker(tanker)
  end
  
  -- Function called when rescue helo is started.
  function rescuehelo_1:OnAfterStart(From, Event, To)
    -- Use rescue helo as radio relay for Marshal.
    AirbossLincoln:SetRadioRelayMarshal(self:GetUnitName())
  end
  
  -- Function called when a player gets graded by the LSO for Lincoln.
  function AirbossLincoln:OnAfterLSOGrade(From, Event, To, playerData, grade)
    local PlayerData = playerData
    local Grade = grade
  
    ----------------------------------------
    --- Interface your Discord bot here! ---
    ----------------------------------------
    
    local score = tonumber(Grade.points)
    local name = tostring(PlayerData.name)
    
    -- Report LSO grade to dcs.log file.
    logInfo(string.format("Player %s scored %.1f", name, score))
  end
end)

-- Create AIRBOSS object. Tarawa
safeExecute(function()
  local AirbossTarawa = AIRBOSS:New("LHA_1 Tarawa")
  
  -- Add recovery windows:
  -- Case I from 9:00 to 10:00 am.
  -- AirbossTarawa:AddRecoveryWindow("8:30", "9:45", 1, nil, true, 25)
  -- Case II with +15 degrees holding offset from 15:00 for 60 min.
  -- AirbossTarawa:AddRecoveryWindow("11:15", "13:00", 1, 15, true, 20)
  -- Case III with +30 degrees holding offset from 2100 to 2200.
  -- AirbossTarawa:AddRecoveryWindow("14:15", "22:00", 1, 30, true, 20)
  
  -- Set TACAN.
  AirbossTarawa:SetTACAN(76, "X", "LHA")
  
  -- Not sure if Tarawa has ICLS?
  AirbossTarawa:SetICLS(16, "LHA")
  
  -- Load all saved player grades from your "Saved Games\DCS" folder (if lfs was desanitized).
  AirbossTarawa:Load()
  
  -- Automatically save player results to your "Saved Games\DCS" folder each time a player gets a final grade from the LSO.
  AirbossTarawa:SetAutoSave()
  
  -- Set radio relay units in order to properly send transmissions with subtitles only visible if correct frequency is tuned in.
  AirbossTarawa:SetRadioRelayLSO("CH-53E Radio Relay")
  -- AirbossTarawa:SetRadioRelayMarshal("SH-60B Radio Relay")
  
  -- Radios.
  AirbossTarawa:SetMarshalRadio(243)
  AirbossTarawa:SetLSORadio(265)
  
  -- Set folder of airboss sound files within miz file.
  AirbossTarawa:SetSoundfilesFolder("Airboss Soundfiles/")
  
  -- Remove landed AI planes from flight deck.
  AirbossTarawa:SetDespawnOnEngineShutdown()
  
  -- Single carrier menu optimization.
  AirbossTarawa:SetMenuSingleCarrier(false)
  
  -- Add Skipper menu to start recovery via F10 radio menu.
  AirbossTarawa:SetMenuRecovery(30, 20, true)
  
  -- Start Airboss.
  AirbossTarawa:Start()
  
  -- Function called when a player gets graded by the LSO for Tarawa.
  function AirbossTarawa:OnAfterLSOGrade(From, Event, To, playerData, grade)
    local PlayerData = playerData
    local Grade = grade
  
    ----------------------------------------
    --- Interface your Discord bot here! ---
    ----------------------------------------
    
    local score = tonumber(Grade.points)
    local name = tostring(PlayerData.name)
    
    -- Report LSO grade to dcs.log file.
    logInfo(self.lid .. string.format("Player %s scored %.1f", name, score))
  end
end)

--[[----------
-- Carrier Passed a waypoint.
function AirbossLincoln:OnAfterPassingWaypoint(From, Event, To, n)
  -- Launch Green Flare.
  self.carrier:FlareGreen()
end
]]

-- Display Current Wind
safeExecute(function()
  local function DisplayWind()
    local wpa, wpp, wtot = AirbossLincoln:GetWindOnDeck()
    local cspeed = AirbossLincoln.carrier:GetVelocityKNOTS()
    local text = string.format("Carrier Speed = %.1f knots, heading=%03d, turning=%s, state=%s.\n", cspeed, AirbossLincoln:GetHeading(), tostring(AirbossLincoln.turning), AirbossLincoln:GetState())
    text = text .. string.format("wind on deck || %.1f, -- %.1f , total %.1f knots.", UTILS.MpsToKnots(wpp), UTILS.MpsToKnots(wtot))
    UTILS.DisplayMissionTime(25)
    MESSAGE:New(text, 25):ToAll()
  end
  SCHEDULER:New(nil, DisplayWind, {}, 30, 30)
end)
