-- Custom logging functions
local function logInfo(message)
  env.info(message)
end

local function logError(message)
  env.error(message)
  local logFile = io.open(lfs.writedir() .. "Logs/airboss_error.log", "a")
  if logFile then
    logFile:write(message .. "\n")
    logFile:close()
  else
    env.error("Failed to open airboss_error.log")
  end
end

-- Function to safely execute code and log errors
local function safeExecute(func, ...)
  local status, err = pcall(func, ...)
  if not status then
    logError(err)
  end
end

-- Ensure MOOSE is loaded
if not _G.BASE then
  logError("MOOSE is not loaded. Ensure that Moose.lua is properly included in the mission.")
  return -- Exit the script if MOOSE is not loaded
end

logInfo("MOOSE is loaded successfully.")

-- Indicate the start of a new mission in the log file
logInfo("-------------------mission start-------------------")
local logFile = io.open(lfs.writedir() .. "Logs/airboss_error.log", "a")
if logFile then
  logFile:write("-------------------mission start-------------------\n")
  logFile:close()
else
  env.error("Failed to open airboss_error.log")
end

--- Naming of objects in ME.
-- Carrier
----------  GroupName   ="CVN 72 Abraham Lincoln"
----------  UnitName    ="CVN 72 Abraham Lincoln"
-- Tanker  
----------  GroupName   ="S_3B Arco"
----------  UnitName    ="S_3B Arco"
-- AWACS  
----------  GroupName   ="E2D Wizard"
----------  UnitName    ="E2D Wizard"
-- rescuehelo_1
----------  GroupName   ="SQ BLUE CH_53E"
----------  UnitName    ="SQ BLUE CH_53E"
-- rescuehelo_2
----------  GroupName   ="SQ BLUE SH_60B"
----------  UnitName    ="SQ BLUE SH_60B"
-- rescuehelo_3
----------  GroupName   ="SQ BLUE SH_60BSC"
----------  UnitName    ="SQ BLUE SH_60BSC"
-- DD for rescuehelo_1 
----------  GroupName   ="CVN 72 Abraham Lincoln"
----------  UnitName    ="USS Perry"
-- DD for rescuehelo_2 
----------  GroupName   ="CVN 72 Abraham Lincoln"
----------  UnitName    ="LHA_1 Tarawa"
-- DD for rescuehelo_3 
----------  GroupName   ="CVN 70 Vinson"
----------  UnitName    ="CVN 70 Vinson"

-- No MOOSE settings menu. Comment out this line if required.
BASE:TraceOnOff(false)

_SETTINGS:SetPlayerMenuOff()

-- Define the tanker, awacs, and rescuehelo_1 variables in a broader scope
local tanker
local awacs
local rescuehelo_1
local AirbossLincoln -- Ensure AirbossLincoln is properly defined in the broader scope

-- S-3B Recovery Tanker spawning in air.
local function createTanker()
  logInfo("Creating RECOVERYTANKER for S_3B Arco.")
  tanker = RECOVERYTANKER:New("CVN 72 Abraham Lincoln", "S_3B Arco")
  if not tanker then
    logError("Failed to create RECOVERYTANKER")
    return
  end
  -- Custom Settings
  tanker:SetTakeoffAir()
  tanker:SetRadio(262)
  tanker:SetModex(262)
  tanker:SetSpeed(350)
  tanker:SetTACAN(62, "ARC")
  tanker:__Start(1)
  logInfo("RECOVERYTANKER for S_3B Arco created and started.")
end

-- E-2D AWACS spawning on Lincoln.
local function createAWACS()
  logInfo("Creating RECOVERYTANKER for E2D Wizard.")
  awacs = RECOVERYTANKER:New("CVN 72 Abraham Lincoln", "E2D Wizard")
  if not awacs then
    logError("Failed to create RECOVERYTANKER for AWACS")
    return
  end
  -- Custom Settings
  awacs:SetAWACS()
  awacs:SetTakeoffAir()
  awacs:SetRadio(251)
  awacs:SetAltitude(25000)
  awacs:SetCallsign(CALLSIGN.AWACS.Wizard)
  awacs:SetRacetrackDistances(30, 50)
  awacs:SetModex(251)
  awacs:SetTACAN(51, "WIZ")
  awacs:__Start(1)
  logInfo("RECOVERYTANKER for E2D Wizard created and started.")
end

-- Rescue Helo with home base USS Perry. Has to be a global object!
local function createRescueHelo()
  logInfo("Creating RESCUEHELO for SQ BLUE CH_53E.")
  rescuehelo_1 = RESCUEHELO:New("CVN 72 Abraham Lincoln", "SQ BLUE CH_53E")
  if not rescuehelo_1 then
    logError("Failed to create RESCUEHELO")
    return
  end
  rescuehelo_1:SetHomeBase(AIRBASE:FindByName("USS Perry"))
  rescuehelo_1:SetRescueZone(10)
  rescuehelo_1:SetTakeoffCold()
  rescuehelo_1:SetModex(42)
  rescuehelo_1:__Start(1)
  logInfo("RESCUEHELO for SQ BLUE CH_53E created and started.")
end

-- new AIRBOSS functions
-- Lincoln
local function createAirbossLincoln()
  logInfo("Creating AIRBOSS for CVN 72 Abraham Lincoln.")
  AirbossLincoln = AIRBOSS:New("CVN 72 Abraham Lincoln", "CVN 72 Abraham Lincoln")
  if not AirbossLincoln then
    logError("Failed to create AIRBOSS for Lincoln")
    return
  end
  AirbossLincoln:SetFunkManOn(10042, "127.0.0.1") -- CHANGE THIS TO YOUR DCS SERVERBOT PORT!
  AirbossLincoln:SetCollisionDistance(10)
  AirbossLincoln:SetTACAN(72, "X", "ABL")
  AirbossLincoln:SetICLS(12, "ABL")
  AirbossLincoln:SetMarshalRadio(127.4, "AM") -- Adjusted frequency format
  AirbossLincoln:SetWelcomePlayers(false)
  AirbossLincoln:SetMenuRecovery(30, 25, true, nil)
  AirbossLincoln:SetSoundfilesFolder("Airboss Soundfiles/")
  AirbossLincoln:SetDespawnOnEngineShutdown()
  AirbossLincoln:SetMPWireCorrection(12) -- Adjusts wire error in MP
  AirbossLincoln:Start()
  logInfo("AIRBOSS for CVN 72 Abraham Lincoln created and started.")

  -- Function called when recovery tanker is started.
  function tanker:OnAfterStart(From, Event, To)
    -- Set recovery tanker.
    if AirbossLincoln then
      AirbossLincoln:SetRecoveryTanker(tanker)
      -- Use tanker as radio relay unit for LSO transmissions.
      AirbossLincoln:SetRadioRelayLSO(self:GetUnitName())
      logInfo("Recovery tanker set for AIRBOSS Lincoln.")
    else
      logError("AirbossLincoln is nil when setting recovery tanker")
    end
  end

  -- Function called when AWACS is started.
  function awacs:OnAfterStart(From, Event, To)
    -- Set AWACS.
    if AirbossLincoln then
      AirbossLincoln:SetRecoveryTanker(tanker)
      logInfo("AWACS set for AIRBOSS Lincoln.")
    else
      logError("AirbossLincoln is nil when setting AWACS")
    end
  end

  -- Function called when rescue helo is started.
  function rescuehelo_1:OnAfterStart(From, Event, To)
    -- Use rescue helo as radio relay for Marshal.
    if AirbossLincoln then
      AirbossLincoln:SetRadioRelayMarshal(self:GetUnitName())
      logInfo("Rescue helo set for AIRBOSS Lincoln.")
    else
      logError("AirbossLincoln is nil when setting rescue helo")
    end
  end

  -- Function called when a player gets graded by the LSO for Lincoln.
  function AirbossLincoln:OnAfterLSOGrade(From, Event, To, playerData, grade)
    local PlayerData = playerData
    local Grade = grade

    ----------------------------------------
    --- Interface your Discord bot here! ---
    ----------------------------------------

    local score = tonumber(Grade.points)
    local name = tostring(PlayerData.name)

    -- Report LSO grade to dcs.log file.
    logInfo(string.format("Player %s scored %.1f", name, score))
  end
end

safeExecute(createTanker)
safeExecute(createAWACS)
safeExecute(createRescueHelo)
safeExecute(createAirbossLincoln)

-- Display Current Wind
safeExecute(function()
  local function DisplayWind()
    if AirbossLincoln then
      local wpa, wpp, wtot = AirbossLincoln:GetWindOnDeck()
      local cspeed = AirbossLincoln.carrier:GetVelocityKNOTS()
      local text = string.format("Carrier Speed = %.1f knots, heading=%03d, turning=%s, state=%s.\n", cspeed, AirbossLincoln:GetHeading(), tostring(AirbossLincoln.turning), AirbossLincoln:GetState())
      text = text .. string.format("wind on deck || %.1f, -- %.1f , total %.1f knots.", UTILS.MpsToKnots(wpp), UTILS.MpsToKnots(wtot))
      UTILS.DisplayMissionTime(25)
      MESSAGE:New(text, 25):ToAll()
    else
      logError("AirbossLincoln is nil in DisplayWind")
    end
  end
  SCHEDULER:New(nil, DisplayWind, {}, 30, 30)
  logInfo("Scheduler for DisplayWind set up.")
end)
