-- Debug flag to enable/disable detailed logging
local DEBUG = true

-- Custom logging functions
local function logInfo(message)
  if DEBUG then
    env.info(message)
  end
end

local function logError(message)
  env.error(message)
  local logFile = io.open(lfs.writedir() .. "Logs/airboss_error.log", "a")
  if logFile then
    logFile:write(message .. "\n")
    logFile:close()
  else
    env.error("Failed to open airboss_error.log")
  end
end

-- Function to safely execute code and log errors
local function safeExecute(func, ...)
  local status, err = pcall(func, ...)
  if not status then
    logError(err)
  end
end

--- Naming of objects in ME ---
-- Carrier
-- GroupName   = "CVN 72 Abraham Lincoln"
-- UnitName    = "CVN 72 Abraham Lincoln"

-- No MOOSE settings menu. Comment out this line if required.
BASE:TraceOnOff(false)
_SETTINGS:SetPlayerMenuOff()

-- Airboss for Lincoln
safeExecute(function()
  logInfo("Creating AIRBOSS for CVN 72 Abraham Lincoln.")
  local AirbossLincoln = AIRBOSS:New("CVN 72 Abraham Lincoln", "CVN 72 Abraham Lincoln")
  if not AirbossLincoln then
    logError("Failed to create AIRBOSS for Lincoln")
    return
  end
  AirbossLincoln:SetFunkManOn(10042, "127.0.0.1") -- CHANGE THIS TO YOUR DCS SERVERBOT PORT!
  AirbossLincoln:SetTACAN(72, "X", "ABL")
  AirbossLincoln:SetICLS(12, "ABL")
  AirbossLincoln:SetMarshalRadio(127.4, "AM") -- Adjusted frequency format
  AirbossLincoln:SetWelcomePlayers(false)
  AirbossLincoln:SetSoundfilesFolder("Airboss Soundfiles/")
  AirbossLincoln:Start()
  logInfo("AIRBOSS for CVN 72 Abraham Lincoln created and started.")

  -- Function called when a player gets graded by the LSO for Lincoln
  function AirbossLincoln:OnAfterLSOGrade(From, Event, To, playerData, grade)
    local PlayerData = playerData
    local Grade = grade

    ----------------------------------------
    --- Interface your Discord bot here! ---
    ----------------------------------------

    local score = tonumber(Grade.points)
    local name = tostring(PlayerData.name)

    -- Report LSO grade to dcs.log file
    logInfo(string.format("Player %s scored %.1f", name, score))
  end
end)
