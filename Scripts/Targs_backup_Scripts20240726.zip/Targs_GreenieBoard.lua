-- Targs_GreenieBoard.lua

-- Enable debug logging
local DEBUG = true

-- Custom logging functions
local function logInfo(message)
  if DEBUG then
    env.info(message)
  end
end

local function logError(message)
  env.error(message)
  local logFile = io.open(lfs.writedir() .. "Logs/TargsGreenieBoard.log", "a")
  if logFile then
    logFile:write(message .. "\n")
    logFile:close()
  else
    env.error("Failed to open TargsGreenieBoard.log")
  end
end

-- Ensure the 'package' global is available
if not package then
  package = {}
end

-- Function to safely execute code and log errors
local function safeExecute(func, ...)
  local status, err = pcall(func, ...)
  if not status then
    logError(err)
  end
end

-- AIRBOSS setup
local airboss = AIRBOSS:New("CVN 72 Abraham Lincoln", "CVN 72 Abraham Lincoln")

function airboss:OnAfterLSOGrade(From, Event, To, playerData, grade)
  local PlayerData = playerData
  local Grade = grade
  local score = tonumber(Grade.points)
  local name = tostring(PlayerData.name)
  
  -- Debug log for message creation
  logInfo("Creating AIRBOSS message for player: " .. name)
  
  -- Create message
  local msg = {}
  msg.command = "onMissionEvent"
  msg.eventName = "S_EVENT_AIRBOSS"
  msg.initiator = {}
  msg.initiator.name = PlayerData.name
  msg.place = {}
  msg.place.name = Grade.carriername
  msg.points = Grade.points
  msg.grade = Grade.grade
  msg.details = Grade.details
  msg.case = Grade.case
  msg.wire = PlayerData.wire
  msg.trapsheet = "AIRBOSS-trapsheet-" .. name  -- Adjust this as per your trapsheet naming convention
  msg.time = timer.getTime()
  
  -- Send message to DCSServerBot
  dcsbot.sendBotTable(msg)
  
  -- Debug log for message sending
  logInfo("AIRBOSS message sent for player: " .. name)
end

-- Initialize AIRBOSS settings
safeExecute(function()
  logInfo("Initializing AIRBOSS settings for CVN 72 Abraham Lincoln.")
  airboss:SetFunkManOn(10042, "127.0.0.1")  -- Ensure this is correct
  airboss:Start()
  logInfo("AIRBOSS settings initialized for CVN 72 Abraham Lincoln.")
end)
