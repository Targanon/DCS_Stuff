-------------------------
-- AIRBOSS Targs Script SB3 Tanker --
-------------------------

-- Debug flag to enable/disable detailed logging
local DEBUG = true

-- Custom logging functions
local function logInfo(message)
  if DEBUG then
    env.info(message)
  end
end

local function logError(message)
  env.error(message)
  local logFile = io.open(lfs.writedir() .. "Logs/airboss_error.log", "a")
  logFile:write(message .. "\n")
  logFile:close()
end

-- Function to safely execute code and log errors
local function safeExecute(func, ...)
  local status, err = pcall(func, ...)
  if not status then
    logError(err)
  end
end

---Naming of objects in ME.
-- Carrier
----------  GroupName   ="CVN 72 Abraham Lincoln"
----------  UnitName    ="CVN 72 Abraham Lincoln"
-- Tanker  
----------  GroupName   ="S_3B Arco"
----------  UnitName    ="S_3B Arco"
-- AWACS  
----------  GroupName   ="E2D Wizard"
----------  UnitName    ="E2D Wizard"
-- rescuehelo_1
----------  GroupName   ="SQ BLUE CH_53E"
----------  UnitName    ="SQ BLUE CH_53E"
-- rescuehelo_2
----------  GroupName   ="SQ BLUE SH_60B"
----------  UnitName    ="SQ BLUE SH_60B"
-- rescuehelo_3
----------  GroupName   ="SQ BLUE SH_60BSC"
----------  UnitName    ="SQ BLUE SH_60BSC"
-- DD for rescuehelo_1 
----------  GroupName   ="CVN 72 Abraham Lincoln"
----------  UnitName    ="USS Perry"
-- DD for rescuehelo_2 
----------  GroupName   ="CVN 72 Abraham Lincoln"
----------  UnitName    ="LHA_1 Tarawa"
-- DD for rescuehelo_3 
----------  GroupName   ="CVN 70 Vinson"
----------  UnitName    ="CVN 70 Vinson"

-- No MOOSE settings menu. Comment out this line if required.
BASE:TraceOnOff(false)

_SETTINGS:SetPlayerMenuOff()

-- S-3B Recovery Tanker spawning in air.
safeExecute(function()
  local tanker = RECOVERYTANKER:New("CVN 72 Abraham Lincoln", "S_3B Arco")
  -- Custom Settings
  tanker:SetTakeoffAir()
  tanker:SetRadio(262)
  tanker:SetModex(262)
  tanker:SetSpeed(350)
  tanker:SetTACAN(62, "ARC")
  tanker:__Start(1)
end)

-- E-2D AWACS spawning on Lincoln.
safeExecute(function()
  local awacs = RECOVERYTANKER:New("CVN 72 Abraham Lincoln", "E2D Wizard")
  -- Custom Settings
  awacs:SetAWACS()
  awacs:SetTakeoffAir()
  awacs:SetRadio(251)
  awacs:SetAltitude(25000)
  awacs:SetCallsign(CALLSIGN.AWACS.Wizard)
  awacs:SetRacetrackDistances(30, 50)
  awacs:SetModex(251)
  awacs:SetTACAN(51, "WIZ")
  awacs:__Start(1)
end)

-- Rescue Helo with home base USS Perry. Has to be a global object!
safeExecute(function()
  local rescuehelo_1 = RESCUEHELO:New("CVN 72 Abraham Lincoln", "SQ BLUE CH_53E")
  rescuehelo_1:SetHomeBase(AIRBASE:FindByName("USS Perry"))
  rescuehelo_1:SetRescueZone(10)
  rescuehelo_1:SetTakeoffCold()
  rescuehelo_1:SetModex(42)
  rescuehelo_1:__Start(1)
end)


-- new AIRBOSS functions
-- Lincoln
safeExecute(function()
  local AirbossLincoln = AIRBOSS:new("CVN 72 Abraham Lincoln", "CVN 72 Abraham Lincoln")
  AirbossLincoln:SetFunkManOn(10042, "127.0.0.1") -- CHANGE THIS TO YOUR DCS SERVERBOT PORT!
  AirbossLincoln:SetCollisionDistance(10)
  AirbossLincoln:SetTACAN(72, "X", "ABL")
  AirbossLincoln:SetICLS(12, "ABL")
  AirbossLincoln:SetMarshalRadio(127400, "AM") -- is the freq right on this?
  AirbossLincoln:SetWelcomePlayers(false)
  AirbossLincoln:SetMenuRecovery(30, 25, true, nil)
  AirbossLincoln:SetSoundfilesFolder("Airboss Soundfiles/")
  AirbossLincoln:SetDespawnOnEngineShutdown()
  airbossLincoln:SetMPWireCorrection(12) -- Adjusts wire error in MP
  AirbossLincoln:Start()
    -- Function called when recovery tanker is started.
    function tanker:OnAfterStart(From, Event, To)
      -- Set recovery tanker.
      AirbossLincoln:SetRecoveryTanker(tanker)
    
      -- Use tanker as radio relay unit for LSO transmissions.
      AirbossLincoln:SetRadioRelayLSO(self:GetUnitName())
    end
    
    -- Function called when AWACS is started.
    function awacs:OnAfterStart(From, Event, To)
      -- Set AWACS.
      AirbossLincoln:SetRecoveryTanker(tanker)
    end
    
    -- Function called when rescue helo is started.
    function rescuehelo_1:OnAfterStart(From, Event, To)
      -- Use rescue helo as radio relay for Marshal.
      AirbossLincoln:SetRadioRelayMarshal(self:GetUnitName())
    end
end)

-- Tarawa
safeExecute(function ()
  local AirbossTarawa = AIRBOSS:New("LHA_1 Tarawa")
  AirbossTarawa:SetFunkManOn(10042, "127.0.0.1") --AGAIN CHANGE TO DCS SERVERBOT PORT
  AirbossTarawa:SetTACAN(76, "X", "LHA")
  AirbossTarawa:SetICLS(16, "LHA")
  AirbossTarawa:SetRadioRelayLSO("CH-53E Radio Relay")
  AirbossTarawa:SetMarshalRadio(243)
  AirbossTarawa:SetLSORadio(265)
  AirbossTarawa:SetSoundfilesFolder("Airboss Soundfiles/")
  AirbossTarawa:SetDespawnOnEngineShutdown()
  AirbossTarawa:SetMenuRecovery(30, 20, true)
  AirbossTarawa:Start()

  
end)



-- Display Current Wind
safeExecute(function()
  local function DisplayWind()
    local wpa, wpp, wtot = AirbossLincoln:GetWindOnDeck()
    local cspeed = AirbossLincoln.carrier:GetVelocityKNOTS()
    local text = string.format("Carrier Speed = %.1f knots, heading=%03d, turning=%s, state=%s.\n", cspeed, AirbossLincoln:GetHeading(), tostring(AirbossLincoln.turning), AirbossLincoln:GetState())
    text = text .. string.format("wind on deck || %.1f, -- %.1f , total %.1f knots.", UTILS.MpsToKnots(wpp), UTILS.MpsToKnots(wtot))
    UTILS.DisplayMissionTime(25)
    MESSAGE:New(text, 25):ToAll()
  end
  SCHEDULER:New(nil, DisplayWind, {}, 30, 30)
end)
